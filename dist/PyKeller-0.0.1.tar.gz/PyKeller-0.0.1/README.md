# PyKeller

These are the packages and scripts I use for my science and engineering research.

## Included Packages

There are the following packages:

```
atmos_sci #Atmospheric Science analysis functions
	atmos_refractivity
	met_analysis
	pbl_lidar
	radiosonde
fiber_bragg_gratings #Fiber Bragg Grating analysis functions
	fbg_analysis
signal_processing #Signal Processing functions
	image_analysis
	pycuda_wavelets
	signal_analysis
	wavelets
```


